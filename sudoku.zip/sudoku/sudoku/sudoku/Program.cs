﻿using System;

namespace sudoku
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("");

            Sudoku sudoku = new Sudoku();
            Riga riga = new Riga();
            Colonna colonna = new Colonna();
            TrePerTre trePerTre = new TrePerTre();

            Console.WriteLine("\n" + sudoku.VisualizzaCampo());
            Console.WriteLine(riga.VerificaRiga(3));
            Console.WriteLine(colonna.VerificaColonna(3));

            Console.WriteLine(trePerTre.VerificaTrePerTre(1));
        }
    }
}
