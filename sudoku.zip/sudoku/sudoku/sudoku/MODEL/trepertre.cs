﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sudoku
{
    class TrePerTre : Sudoku
    {
        int _xInizio;
        int _yInizio;
        int _xFine;
        int _yFine;

        public TrePerTre()
        { }

        public string VerificaTrePerTre(int numeroTrePreTre)
        {
            // Controllo il numero del quadrante e imposto le coordiante dei punti
            switch (numeroTrePreTre)
            {
                // Primo quadrato (0,0 3,3)
                case 1:
                    _xInizio = 0;
                    _yInizio = 0;
                    _xFine = 3;
                    _yFine = 3;
                    break;
                case 2: // Secondo quadrato
                    _xInizio = 3;
                    _yInizio = 0;
                    _xFine = 6;
                    _yFine = 3;
                    break;
                case 3: // Terzo quadrato
                    _xInizio = 6;
                    _yInizio = 0;
                    _xFine = 9;
                    _yFine = 3;
                    break;
                case 4: // Quarto quadrato
                    _xInizio = 0;
                    _yInizio = 3;
                    _xFine = 3;
                    _yFine = 6;
                    break;
                case 5: // Quinto quadrato
                    _xInizio = 3;
                    _yInizio = 3;
                    _xFine = 6;
                    _yFine = 6;
                    break;
                case 6: // Sesto quadrato
                    _xInizio = 3;
                    _yInizio = 6;
                    _xFine = 9;
                    _yFine = 6;
                    break;
                case 7: // Settimo quadrato
                    _xInizio = 0;
                    _yInizio = 6;
                    _xFine = 9;
                    _yFine = 3;
                    break;
                case 8: // Ottavo quadrato
                    _xInizio = 3;
                    _yInizio = 6;
                    _xFine = 9;
                    _yFine = 6;
                    break;
                case 9: // Nono quadrato
                    _xInizio = 6;
                    _yInizio = 6;
                    _xFine = 9;
                    _yFine = 9;
                    break;
                default: // Per default imposto il primo quadrante
                    _xInizio = 0;
                    _yInizio = 0;
                    _xFine = 3;
                    _yFine = 3;
                    break;
            }

            // Dentro il 3x3 Devo vedere se ci sono dei numeri che si ripetono, quindi 4 for
            for (int i = _yInizio; i < _yFine; i++)
                for (int j = _xInizio; j < _xFine - 1; j++)
                    for (int k = i; k < _yFine; k++)
                        for (int l = j + 1; l < _xFine; l++)
                            if (_campo[i, j] == _campo[k, l])
                                return $"Il numero {_campo[k, l]} si ripete nel quadrato numero {numeroTrePreTre}!";

            return $"Il 3x3 selezionato({numeroTrePreTre}) non contiente errori!";
        }
    }
}
