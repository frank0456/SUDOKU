﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sudoku
{
    class Colonna : Sudoku
    {
        public Colonna()
        { }

        public string VerificaColonna(int numeroColonna)
        {
            for (int col = 0; col < _campo.GetLength(1) - 1; col++)
                for (int j = col + 1; j < _campo.GetLength(0); j++)
                    if (_campo[col, numeroColonna] == _campo[j, numeroColonna])
                        return $"Il numero {_campo[j, numeroColonna]} della colonna {numeroColonna} si ripete!";

            return $"La colonna selezionata ({numeroColonna}) non contiene errori!";
        }
    }
}
