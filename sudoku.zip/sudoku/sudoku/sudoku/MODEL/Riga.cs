﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sudoku
{
    class Riga : Sudoku
    {
        public Riga()
        { }

        public string VerificaRiga(int numeroRiga)
        {
            for (int i = 0; i < _campo.GetLength(0) - 1; i++)
                for (int j = i + 1; j < _campo.GetLength(1); j++)
                    if (_campo[numeroRiga, i] == _campo[numeroRiga, j])
                        return $"Il numero {_campo[numeroRiga, j]} della riga {numeroRiga} si ripete!";

            return $"La riga selezionata ({numeroRiga}) non contiene errori!";
        }
    }
}
